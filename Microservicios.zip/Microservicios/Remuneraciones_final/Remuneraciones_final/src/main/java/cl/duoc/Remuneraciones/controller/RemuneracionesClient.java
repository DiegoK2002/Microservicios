package cl.duoc.Remuneraciones.controller;

public interface RemuneracionesClient {

}
