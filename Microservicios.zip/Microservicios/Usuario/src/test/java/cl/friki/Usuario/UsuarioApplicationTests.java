package cl.friki.Usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
