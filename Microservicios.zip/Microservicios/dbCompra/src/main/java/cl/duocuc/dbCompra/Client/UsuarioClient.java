package cl.duocuc.dbCompra.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "db-usuario", url = "http://localhost:8082")
public interface UsuarioClient {
    @GetMapping("/api/v1/usuarios/dto/{id}")
    Object obtenerDatosUsuario(@PathVariable("id") Integer id);
}