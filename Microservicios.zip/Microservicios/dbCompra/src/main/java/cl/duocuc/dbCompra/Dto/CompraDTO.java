package cl.duocuc.dbCompra.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompraDTO {
    private Integer id;
    private String fechaCompra;
    private Integer valorTotal;
}
