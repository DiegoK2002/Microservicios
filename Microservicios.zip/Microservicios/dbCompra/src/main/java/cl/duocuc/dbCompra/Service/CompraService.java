package cl.duocuc.dbCompra.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.dbCompra.Client.ProductoClient;
import cl.duocuc.dbCompra.Model.Compra;
import cl.duocuc.dbCompra.Repository.CompraRepository;

@Service
public class CompraService {
    @Autowired
    private CompraRepository repo;

    @Autowired
    private ProductoClient productoClient;

    public List<Compra> listaCompras(){
        return repo.findAll();
    }

    public Compra buscarPorId(Integer id){
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Compra no encontrado"));
    }

    public Compra guardarCompra(Compra compra) {
        if (compra.getMetodoPago() == null) {
            throw new RuntimeException("Debe seleccionar un método de pago");
        }
        return repo.save(compra);
    }
}
