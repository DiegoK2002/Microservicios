package cl.duocuc.dbEnvio.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "db-compra", url = "http://localhost:8084")
public interface CompraClient {
    @GetMapping("/api/v1/compras/id/{id}")
    Object obtenerCompraPorId(@PathVariable("id") Integer id);
}