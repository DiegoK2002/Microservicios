package cl.duocuc.dbEnvio.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "db-notificaciones", url = "http://localhost:8088")
public interface NotificacionClient {
    @PostMapping("/api/v1/notificaciones")
    Object enviarAlertaEnvio(@RequestBody Object notificacion);
}