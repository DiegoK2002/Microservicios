package cl.duocuc.dbResenas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbResenasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbResenasApplication.class, args);
	}

}
