package cl.duocuc.dbResenas.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResenasDTO {
    private Integer id;
    private String NombreProducto;
    private Integer Puntaje;
    private String Descripcion;
}
