package cl.duoc.Reembolsos.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.Reembolsos.DTO.ReembolsosDTO;
import cl.duoc.Reembolsos.Model.Reembolso;
import cl.duoc.Reembolsos.Service.ReembolsoService;

@RestController
@RequestMapping("/reembolsos")
public class ReembolsosController {

    @Autowired
    private ReembolsoService service;

    @GetMapping
    public ResponseEntity<List<Reembolso>> listarReembolsos(){
        
        List<Reembolso> listaReembolsos = service.listarReembolsos();

        if(listaReembolsos.isEmpty()){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(listaReembolsos);
        }
    }

    //buscar producto por id
    @GetMapping("/{id}")
    public ResponseEntity<Reembolso> buscarPorId(@PathVariable Integer id){
        try{
            Reembolso reembolso = service.buscarPorId(id);
            return ResponseEntity.ok(reembolso);
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    //crear producto nuevo
    @PostMapping
    public ResponseEntity<Reembolso> guardar(@RequestBody Reembolso reembolso){
        return ResponseEntity.ok(service.crearReembolso(reembolso));
    }

    //eliminar producto
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Integer id){
        try{
            service.eliminarReembolso(id);
            return ResponseEntity.noContent().build();
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    
    @PutMapping("/{id}")
    public ResponseEntity<Reembolso> actualizar(@PathVariable Integer id, @RequestBody Reembolso reembolso){
        try{
            return ResponseEntity.ok(service.actualizarReembolso(id, reembolso));
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    //buscar dto por id
    @GetMapping("/dto/{id}")
    public ResponseEntity<ReembolsosDTO> obtenerReembolsosDTO(@PathVariable Integer id){
        try{
            Reembolso reembolso = service.buscarPorId(id);

            ReembolsosDTO dto = new ReembolsosDTO();

            dto.setId(reembolso.getId());
            dto.setNombreReembolso(reembolso.getNombreReembolso());
            dto.setMonto(reembolso.getMonto());
            dto.setFecha(reembolso.getFecha());
            dto.setEstado(reembolso.getEstado());
            dto.setDescripcion(reembolso.getDescripcion());

            return ResponseEntity.ok(dto);
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
