package cl.duoc.Reembolsos.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReembolsosDTO {
    
    private Integer id;
    private String nombreProducto;
    private Integer precio;

}
