package cl.duoc.Reembolsos.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Reembolsos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reembolso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, unique = true)
    private String nombreProducto;

    @Column(nullable = false, unique = true)
    private Integer cantProducto;

    @Column(nullable = false, unique = true)
    private Integer precio;

    @Column(nullable = false, unique = true)
    private String tipoProducto;
}
