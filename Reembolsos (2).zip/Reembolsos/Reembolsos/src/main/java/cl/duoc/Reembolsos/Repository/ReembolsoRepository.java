package cl.duoc.Reembolsos.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duoc.Reembolsos.Model.Reembolso;

@Repository
public interface ReembolsoRepository extends JpaRepository<Reembolso, Integer>{

    Optional<Reembolso> findById(String id);

}
