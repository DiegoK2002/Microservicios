package cl.duoc.Reembolsos.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duoc.Reembolsos.Model.Reembolso;
import cl.duoc.Reembolsos.Repository.ReembolsoRepository;

@Service
public class ReembolsoService {


    @Autowired
    private ReembolsoRepository reembolsoRepository;

    //buscar a todos los reembolsos
    public List<Reembolso> listarReembolsos(){
        return reembolsoRepository.findAll();
    }

    //buscar reembolso por id
    public Reembolso buscarPorId(Integer id){
        return reembolsoRepository.findById(id).orElseThrow(() -> new RuntimeException("no se encontró ese reembolso"));
    }


    public Reembolso crearReembolso(Reembolso reembolso){
        return reembolsoRepository.save(reembolso);
    }

    
    public Reembolso actualizarReembolso(Integer id, Reembolso reembolsoActualizado){
        Reembolso reembolsoAnt = reembolsoRepository.findById(id).orElseThrow(()-> new RuntimeException("Reembolso no encontrado"));
        
        reembolsoAnt.setMonto(reembolsoActualizado.getMonto());
        reembolsoAnt.setFecha(reembolsoActualizado.getFecha());
        reembolsoAnt.setEstado(reembolsoActualizado.getEstado());

        return reembolsoRepository.save(reembolsoAnt);
    }

    
    public void eliminarReembolso(Integer id){
        if(reembolsoRepository.existsById(id)){
            reembolsoRepository.deleteById(id);
            
        }else{
           throw new RuntimeException("Reembolso no Disponible"); 
        }
    }









}
