-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-05-2026 a las 00:32:07
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `remuneraciones_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `remuneraciones`
--

CREATE TABLE `remuneraciones` (
  `id` int(11) NOT NULL,
  `bonificacion` double NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `descuentos` double NOT NULL,
  `estado` varchar(255) NOT NULL,
  `fecha_pago` varchar(255) NOT NULL,
  `nombre_empleado` varchar(255) NOT NULL,
  `salario_base` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `remuneraciones`
--

INSERT INTO `remuneraciones` (`id`, `bonificacion`, `descripcion`, `descuentos`, `estado`, `fecha_pago`, `nombre_empleado`, `salario_base`) VALUES
(1, 50000, 'Actualización de sueldo y estado', 120000, 'Pagado', '2026-05-13', 'Joaquin Dupre', 950000),
(2, 50000, 'Pago mayo 2026', 120000, 'Pendiente', '2026-05-12', 'Joaquin Dupre', 850000);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `remuneraciones`
--
ALTER TABLE `remuneraciones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `remuneraciones`
--
ALTER TABLE `remuneraciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
