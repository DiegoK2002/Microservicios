package com.stock.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.stock.model.Producto;
import com.stock.service.ProductoService;

// Controlador REST del microservicio de Control de Stock
// Puerto: 8084
@RestController
@RequestMapping("/api/v1/stock")
public class ProductoController {

    @Autowired
    private ProductoService service;

    // GET /api/v1/stock → lista todos los productos con su stock
    @GetMapping
    public ResponseEntity<List<Producto>> listar() {
        List<Producto> lista = service.listar();
        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(lista);
    }

    // GET /api/v1/stock/{id} → buscar producto por ID
    @GetMapping("/{id}")
    public ResponseEntity<Producto> buscar(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(service.buscarPorId(id));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // POST /api/v1/stock → crear nuevo producto
    @PostMapping
    public ResponseEntity<Producto> crear(@RequestBody Producto p) {
        Producto nuevo = service.guardar(p);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
    }

    // PUT /api/v1/stock/{id} → actualizar producto
    @PutMapping("/{id}")
    public ResponseEntity<Producto> actualizar(@PathVariable Long id,
                                               @RequestBody Producto p) {
        try {
            return ResponseEntity.ok(service.actualizar(id, p));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE /api/v1/stock/{id} → eliminar producto
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        try {
            service.eliminar(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // GET /api/v1/stock/validar/{id}/{cantidad}
    // Valida si hay stock suficiente - llamado por dbCompra
    @GetMapping("/validar/{id}/{cantidad}")
    public ResponseEntity<Boolean> validar(@PathVariable Long id,
                                           @PathVariable int cantidad) {
        boolean disponible = service.validarStock(id, cantidad);
        return ResponseEntity.ok(disponible);
    }

    // PUT /api/v1/stock/descontar/{id}/{cantidad}
    // Descuenta stock al confirmar compra - llamado por dbCompra
    @PutMapping("/descontar/{id}/{cantidad}")
    public ResponseEntity<String> descontar(@PathVariable Long id,
                                            @PathVariable int cantidad) {
        try {
            service.descontarStock(id, cantidad);
            return ResponseEntity.ok("Stock descontado correctamente");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // PUT /api/v1/stock/reponer/{id}/{cantidad}
    // Repone stock cuando llega nueva mercaderia
    @PutMapping("/reponer/{id}/{cantidad}")
    public ResponseEntity<String> reponer(@PathVariable Long id,
                                          @PathVariable int cantidad) {
        try {
            service.reponerStock(id, cantidad);
            return ResponseEntity.ok("Stock repuesto correctamente");
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
