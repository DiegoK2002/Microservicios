package com.stock.dto;

import lombok.*;

// DTO para compartir datos del producto con otros microservicios
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductoDTO {
    private Long id;
    private String nombre;
    private Integer stock;
    private Integer precio;
}
