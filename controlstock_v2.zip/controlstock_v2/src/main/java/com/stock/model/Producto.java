package com.stock.model;

import jakarta.persistence.*;
import lombok.*;

// Modelo que representa un producto con su stock
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "producto")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nombre del producto
    @Column(nullable = false)
    private String nombre;

    // Cantidad disponible en stock
    @Column(nullable = false)
    private Integer stock;

    // Precio unitario del producto
    @Column(nullable = false)
    private Integer precio;
}
