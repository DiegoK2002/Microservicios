package com.stock.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.stock.model.Producto;

// Repositorio de Producto - acceso a base de datos MySQL
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {
}
