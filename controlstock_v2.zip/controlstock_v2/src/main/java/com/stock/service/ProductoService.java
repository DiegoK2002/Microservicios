package com.stock.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.stock.model.Producto;
import com.stock.repository.ProductoRepository;

// Logica de negocio para el Control de Stock
@Service
public class ProductoService {

    @Autowired
    private ProductoRepository repo;

    // Listar todos los productos con su stock
    public List<Producto> listar() {
        return repo.findAll();
    }

    // Buscar producto por ID
    public Producto buscarPorId(Long id) {
        return repo.findById(id)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado con id: " + id));
    }

    // Guardar nuevo producto
    public Producto guardar(Producto p) {
        return repo.save(p);
    }

    // Actualizar producto existente
    public Producto actualizar(Long id, Producto productoActualizado) {
        Producto existente = buscarPorId(id);
        existente.setNombre(productoActualizado.getNombre());
        existente.setStock(productoActualizado.getStock());
        existente.setPrecio(productoActualizado.getPrecio());
        return repo.save(existente);
    }

    // Eliminar producto
    public void eliminar(Long id) {
        if (!repo.existsById(id)) {
            throw new RuntimeException("Producto no encontrado con id: " + id);
        }
        repo.deleteById(id);
    }

    // Validar si hay suficiente stock - usado por dbCompra
    public boolean validarStock(Long id, int cantidad) {
        Producto p = repo.findById(id).orElse(null);
        return p != null && p.getStock() >= cantidad;
    }

    // Descontar stock al realizarse una compra - usado por dbCompra
    public void descontarStock(Long id, int cantidad) {
        Producto p = buscarPorId(id);
        if (p.getStock() < cantidad) {
            throw new RuntimeException("Stock insuficiente para el producto: " + p.getNombre());
        }
        p.setStock(p.getStock() - cantidad);
        repo.save(p);
    }

    // Reponer stock cuando llega nueva mercaderia
    public void reponerStock(Long id, int cantidad) {
        Producto p = buscarPorId(id);
        p.setStock(p.getStock() + cantidad);
        repo.save(p);
    }
}
