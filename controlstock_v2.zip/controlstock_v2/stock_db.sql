-- ================================================
-- BASE DE DATOS: stock_db
-- Microservicio: ms-ControlStock (puerto 8084)
-- Ejecutar en phpMyAdmin -> pestaña SQL
-- ================================================

-- Crear base de datos
DROP DATABASE IF EXISTS stock_db;
CREATE DATABASE stock_db CHARACTER SET utf8 COLLATE utf8_general_ci;
USE stock_db;

-- ================================================
-- TABLA: producto
-- ================================================
CREATE TABLE producto (
    id      BIGINT       AUTO_INCREMENT PRIMARY KEY,
    nombre  VARCHAR(150) NOT NULL,
    stock   INTEGER      NOT NULL DEFAULT 0,
    precio  INTEGER      NOT NULL
);

-- ================================================
-- DATOS DE PRUEBA
-- ================================================
INSERT INTO producto (nombre, stock, precio) VALUES
('Funko Pop Naruto',          50,  15990),
('Funko Pop Dragon Ball Z',   30,  18990),
('Carta Pokemon Charizard',  100,   9990),
('Carta Magic Ancestral',     20,  49990),
('Juego de Mesa Catan',       15,  39990),
('Dado RPG Set 7 piezas',     80,   4990),
('Figura Goku Ultra',         10,  79990),
('Manga One Piece Vol 1',     60,   6990),
('Cosplay Espada Naruto',      5,  34990),
('Mapa Tierra Media',         25,  12990);

-- ================================================
-- VERIFICAR RESULTADO
-- ================================================
SELECT * FROM producto;
