package cl.duocuc.dbCompra.Config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import cl.duocuc.dbCompra.Model.Promociones;
import cl.duocuc.dbCompra.Repository.PromocionesRepository;

@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner initData(PromocionesRepository repo){
        return args -> {
            if(repo.count() == 0){
                repo.save(new Promociones(null, 0.00));
                repo.save(new Promociones(null, 0.10));
                repo.save(new Promociones(null, 0.20));
                repo.save(new Promociones(null, 0.30));
                repo.save(new Promociones(null, 0.40));
                repo.save(new Promociones(null, 0.50));
                repo.save(new Promociones(null, 0.60));
                repo.save(new Promociones(null, 0.70));
                repo.save(new Promociones(null, 0.80));
                repo.save(new Promociones(null, 0.90));
                repo.save(new Promociones(null, 1.00));
            }
        };
    }
}
