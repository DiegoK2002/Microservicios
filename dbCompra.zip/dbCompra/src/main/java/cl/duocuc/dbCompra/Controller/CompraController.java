package cl.duocuc.dbCompra.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.msPaciente.Model.Compra;
import cl.duocuc.msPaciente.Service.CompraService;
import cl.duocuc.msPaciente.dto.CompraDTO;

@RestController
@RequestMapping("/api/v1/compras")
public class CompraController {
    @Autowired
    private CompraService service;

    @GetMapping
    public ResponseEntity<List<Compra>> listarCompras(){
        List<Compra> listaCompras = service.listaCompras();
        if (listaCompras.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.ok(listaCompras);
        }
    }

    @GetMapping("/dto/{id}")
    public ResponseEntity<CompraDTO> buscarDTO(@PathVariable Integer id) {
        try {
            Compra compra = service.buscarPorId(id);
            CompraDTO compraDTO = new CompraDTO();
            compraDTO.setId(compra.getId());
            compraDTO.setFechaCompra(compra.getFechaCompra());
            compraDTO.setValorTotal(compra.getValorTotal());

            return ResponseEntity.ok(compraDTO);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Compra> obtenerCompraPorId(@PathVariable Integer id) {
        try {
            Compra compra = service.buscarPorId(id);
            return ResponseEntity.ok(compra);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Compra> guardarCompra(@RequestBody Compra compra) {
        Compra nuevaCompra = service.guardarCompra(compra);
        return ResponseEntity.ok(nuevaCompra);
    }
}
