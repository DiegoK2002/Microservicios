package cl.duocuc.dbCompra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbCompraApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbCompraApplication.class, args);
	}

}
