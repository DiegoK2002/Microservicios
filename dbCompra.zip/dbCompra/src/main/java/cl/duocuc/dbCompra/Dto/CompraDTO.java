package cl.duocuc.dbCompra.Dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompraDTO {
    private Integer id;
    private Date fechaCompra;
    private Integer valorTotal;
}
