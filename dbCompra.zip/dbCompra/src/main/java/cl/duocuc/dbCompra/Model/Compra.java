package cl.duocuc.dbCompra.Model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstruct
@AllArgsConstruct
@Entity
@Table(name = "compra")
public class Compra {

    @Id
    @GeneratedValue(strategy = GeberationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private Date fechaCompra;

    @Column(nullable = false)
    private Integer valorTotal;

    @ManyToMany(mappedBy = "compra", cascade = CascadeType.ALL)
    @JoinColumn(name ="metodoPago_id")
    private MetodoPago metodoPago;
}
