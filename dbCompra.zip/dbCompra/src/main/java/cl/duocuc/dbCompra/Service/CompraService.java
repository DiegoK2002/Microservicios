package cl.duocuc.dbCompra.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.dbCompra.Model.Compra;
import cl.duocuc.dbCompra.Repository.CompraRepository;

@Service
public class CompraService {
    @Autowired
    private CompraRepository repo;

    public List<Compra> listaCompras(){
        return repo.findAll();
    }

    public Compra buscarPorId(Integer id){
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Compra no encontrado"));
    }

    public Compra guardarCompra(Compra compra) {
        return repo.save(compra);
    }
}
