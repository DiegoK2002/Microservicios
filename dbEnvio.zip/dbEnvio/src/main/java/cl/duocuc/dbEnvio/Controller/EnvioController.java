package cl.duocuc.dbEnvio.Controller;

@RestController
@RequestMapping("/api/v1/envios")
public class EnvioController {
    @Autowired
    private EnvioService service;

    @GetMapping
    public ResponseEntity<List<Envio>> listarEnvios() {
        List<Envio> envios = service.listaEnvios();
        
        if(envios.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(envios);
        }
    }

    @GetMapping("/dto/{id}")
    public ResponseEntity<EnvioDTO> buscarDTO(@PathVariable Integer id) {
        try {
            Doctor envio = service.buscarPorId(id);
            EnvioDTO envioDTO = new EnvioDTO();
            envioDTO.setId(envio.getId());
            return ResponseEntity.ok(envioDTO);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/id")
    public ResponseEntity<Envio> buscarPorId(Integer id) {
        try {
            Envio envio = service.buscarPorId(id);
            return ResponseEntity.ok(envio);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
