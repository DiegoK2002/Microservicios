package cl.duocuc.dbEnvio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbEnvioApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbEnvioApplication.class, args);
	}

}
