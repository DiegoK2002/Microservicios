package cl.duocuc.dbEnvio.Model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstruct
@AllArgsConstruct
@Entity
@Table(name = "envio")
public class Repartidor {

    @Id
    @GeneratedValue(strategy = GeberationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String nombre;

    @OneToMany
    @JoinColumn(name = "envio_id", nullable = false)
    private Envio envio;
}
