package cl.duocuc.dbEnvio.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.dbEnvio.Model.Envio;
import cl.duocuc.dbEnvio.Repository.EnvioRepository;

@Service
public class EnvioService {
    @Autowired
    private EnvioRepository repo;

    public List<Envio> listaEnvios(){
        return repo.findAll();
    }

    public Envio guardarEnvio(Envio envio) {
        return repo.save(envio);
    }

    public Envio buscarPorId(Integer id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Envio no encontrada"));
    }
}