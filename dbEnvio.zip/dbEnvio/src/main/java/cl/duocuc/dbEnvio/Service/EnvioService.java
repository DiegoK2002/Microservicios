package cl.duocuc.dbEnvio.Service;

@Service
public class EnvioService {
    @Autowired
    private EnvioRepository repo;

    public List<Envio> listaEnvios(){
        return repo.findAll();
    }

    public Envio guardarEnvio(Envio envio) {
        return repo.save(envio);
    }

    public Envio buscarPorId(Integer id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Envio no encontrada"));
    }
}