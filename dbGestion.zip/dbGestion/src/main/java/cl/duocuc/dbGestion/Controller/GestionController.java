package cl.duocuc.dbGestion.Controller;

public class GestionController {

}
