package cl.duocuc.dbGestion.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.dbGestion.Dto.GestionDTO;
import cl.duocuc.dbGestion.Model.Gestion;
import cl.duocuc.dbGestion.Service.GestionService;

@RestController
@RequestMapping("/api/v1/gestiones")
public class GestionController {
    @Autowired
    private GestionService service;

    @GetMapping
    public ResponseEntity<List<Gestion>> listarGestiones(){
        List<Gestion> listaGestiones = service.listaGestion();
        if (listaGestiones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.ok(listaGestiones);
        }
    }

    @GetMapping("/dto/{id}")
    public ResponseEntity<GestionDTO> buscarDTO(@PathVariable Integer id) {
        try {
            Gestion gestion = service.buscarPorId(id);
            GestionDTO gestionDTO = new GestionDTO();
            gestionDTO.setId(gestion.getId());
            gestionDTO.setVentasXMes(gestion.getVentasXMes());
            gestionDTO.setVentasTotales(gestion.getVentasTotales());

            return ResponseEntity.ok(gestionDTO);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Gestion> obtenerCompraPorId(@PathVariable Integer id) {
        try {
            Gestion gestion = service.buscarPorId(id);
            return ResponseEntity.ok(gestion);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Gestion> guardarCompra(@RequestBody Gestion gestion) {
        Gestion nuevaGestion = service.guardarGestion(gestion);
        return ResponseEntity.ok(nuevaGestion);
    }
}
