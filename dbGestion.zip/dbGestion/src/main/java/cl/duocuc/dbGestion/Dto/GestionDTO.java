package cl.duocuc.dbGestion.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GestionDTO {
    private Integer id;
    private Integer ventasXMes;
    private Integer ventasTotales;
}
