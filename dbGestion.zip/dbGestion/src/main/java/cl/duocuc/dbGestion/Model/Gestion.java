package cl.duocuc.dbGestion.Model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstrunct
@AllArgsConstrunct
@Entity
@Table(name = "gestion")
public class Gestion {
    
    @Id
    @GeneratedValue(strategy = GeberationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private Integer ventasXMes;

    @Column(nullable= false)
    private Integer ventasTotales;
}
