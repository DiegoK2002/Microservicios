package cl.duocuc.dbGestion.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duocuc.dbGestion.Model.Gestion;

@Repository
public interface GestionRepository extends JpaRepository<Gestion, Integer> {
    Optional<Gestion> findById(Integer id);
}
