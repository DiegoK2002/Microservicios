package cl.duocuc.dbGestion.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.dbGestion.Model.Gestion;
import cl.duocuc.dbGestion.Repository.GestionRepository;

@Service
public class GestionService {
    @Autowired
    private GestionRepository repo;
    
    public List<Gestion> listaGestion(){
        return repo.findAll();
    }

    public Gestion buscarPorId(Integer id){
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Gestion no encontrado"));
    }

    public Gestion guardarGestion(Gestion gestion){
        return repo.save(gestion);
    }
}
