package cl.duocuc.dbGestion.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.dbGestion.Repository.GestionRepository;

@Service
public class GestionService {
    @Autowired
    private GestionRepository repo;
    
}
