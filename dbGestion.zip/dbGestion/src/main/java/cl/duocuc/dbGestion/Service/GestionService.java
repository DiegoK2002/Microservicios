package cl.duocuc.dbGestion.Service;

@Service
public class GestionService {
    @Autowired
    private GestionRepository repo;
    
}
