package cl.duocuc.dbGestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbGestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
