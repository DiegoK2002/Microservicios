package com.stock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.stock.model.Producto;
import com.stock.service.ProductoService;

@RestController
@RequestMapping("/stock")
public class ProductoController {

    @Autowired
    private ProductoService service;

    @PostMapping
    public Producto crear(@RequestBody Producto p) {
        return service.guardar(p);
    }

    @GetMapping
    public Iterable<Producto> listar() {
        return service.listar();
    }

    @GetMapping("/validar/{id}/{cantidad}")
    public boolean validar(@PathVariable Long id, @PathVariable int cantidad) {
        return service.validarStock(id, cantidad);
    }

    @PutMapping("/descontar/{id}/{cantidad}")
    public void descontar(@PathVariable Long id, @PathVariable int cantidad) {
        service.descontarStock(id, cantidad);
    }
}
