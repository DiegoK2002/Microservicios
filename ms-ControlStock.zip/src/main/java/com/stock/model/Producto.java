package com.stock.model;

import jakarta.persistence.*;

@Entity
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private int stock;
    private int precio;

    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public int getStock() { return stock; }
    public int getPrecio() { return precio; }

    public void setId(Long id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setStock(int stock) { this.stock = stock; }
    public void setPrecio(int precio) { this.precio = precio; }
}
