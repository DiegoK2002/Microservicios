package com.stock.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.stock.model.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
}
