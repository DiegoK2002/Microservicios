package com.stock.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.stock.model.Producto;
import com.stock.repository.ProductoRepository;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository repo;

    public boolean validarStock(Long id, int cantidad) {
        Producto p = repo.findById(id).orElse(null);
        return p != null && p.getStock() >= cantidad;
    }

    public void descontarStock(Long id, int cantidad) {
        Producto p = repo.findById(id).orElseThrow();
        p.setStock(p.getStock() - cantidad);
        repo.save(p);
    }

    public Producto guardar(Producto p) {
        return repo.save(p);
    }

    public Iterable<Producto> listar() {
        return repo.findAll();
    }
}
